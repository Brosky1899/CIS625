#!/bin/bash

sbatch ./hw3.sh
