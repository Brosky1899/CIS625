#!/bin/bash

./hw2-omp $SLURM_CPUS_PER_TASK
