#!/bin/bash

./hw2-pthread $SLURM_CPUS_PER_TASK
